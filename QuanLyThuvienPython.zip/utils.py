from datetime import datetime
from decimal import Decimal

from psycopg2 import Error
from psycopg2.errors import UniqueViolation, ForeignKeyViolation, CheckViolation, NotNullViolation

def valid_date(text: str) -> bool:
    try:
        datetime.strptime(text, "%Y-%m-%d")
        return True
    except ValueError:
        return False

def to_none(text: str):
    text = text.strip()
    return text if text else None

def format_money(value) -> str:
    if value is None:
        return "0"
    if isinstance(value, Decimal):
        value = float(value)
    return f"{value:,.0f}"

def clean_db_message(exc: Exception) -> str:
    if isinstance(exc, Error):
        primary = getattr(exc.diag, "message_primary", None)
        if primary:
            return primary.strip()
    return str(exc).strip()

def friendly_error_message(exc: Exception) -> str:
    msg = clean_db_message(exc)

    if isinstance(exc, UniqueViolation):
        if "ten_dang_nhap" in msg.lower():
            return "Tên đăng nhập đã tồn tại."
        if "email" in msg.lower():
            return "Email đã tồn tại."
        if "isbn" in msg.lower():
            return "ISBN đã tồn tại."
        if "ma_ban_sao" in msg.lower():
            return "Mã bản sao đã tồn tại."
        return "Dữ liệu bị trùng, vui lòng kiểm tra lại."

    if isinstance(exc, ForeignKeyViolation):
        return "Không thể xóa hoặc cập nhật vì dữ liệu này đang được sử dụng ở nơi khác."

    if isinstance(exc, CheckViolation):
        return msg or "Dữ liệu không hợp lệ."

    if isinstance(exc, NotNullViolation):
        return "Vui lòng nhập đầy đủ các trường bắt buộc."

    lowered = msg.lower()
    if "duplicate key value violates unique constraint" in lowered:
        return "Dữ liệu bị trùng, vui lòng kiểm tra lại."
    if "violates foreign key constraint" in lowered:
        return "Không thể xóa hoặc cập nhật vì dữ liệu này đang được sử dụng ở nơi khác."
    if "violates not-null constraint" in lowered:
        return "Vui lòng nhập đầy đủ các trường bắt buộc."

    return msg or "Đã xảy ra lỗi không xác định."
